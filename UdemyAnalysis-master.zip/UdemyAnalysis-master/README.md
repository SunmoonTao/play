# Udemy Analysis
This contains the code for the following Medium Article. 
